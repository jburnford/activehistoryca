<?php get_header(); ?>
	<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
		<div class="post" id="post-<?php the_ID(); ?> single">
			<h1><?php the_title(); ?></h1>
			<div class="meta">
				By <?php the_author() ?>
			</div>
			<div class="entry">
				<?php $subtitle = get_post_meta($post->ID, 'subtitle', true);
					if($subtitle) echo '<p class="sub">'.$subtitle.'</p>';
				 ?>
				 <?php the_content(); ?>
				<?php the_tags( '<p class="tags"><small>Tags: ', ', ', '</small></p>'); ?>
				<p class="postmetadata alt">
					<small>
						This entry was posted
						on <?php the_time('l, F jS, Y') ?> at <?php the_time() ?>
						and is filed under <?php the_category(', ') ?>.
						You can follow any responses to this entry through the <?php post_comments_feed_link('RSS 2.0'); ?> feed.
					</small>
				</p>
			</div>
		</div>
	<?php comments_template(); ?>
	<?php endwhile; else: ?>
		<p>Sorry, no posts matched your criteria.</p>
<?php endif; ?>
<?php get_footer(); ?>