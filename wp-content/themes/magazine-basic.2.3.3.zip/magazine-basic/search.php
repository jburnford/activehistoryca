<?php get_header(); ?>
	<?php
    $mySearch =& new WP_Query("s=$s & showposts=-1");
    $num = $mySearch->post_count;
    echo '<h1 class="catheader">'.$num.' search results for "'; the_search_query(); echo '"</h1>';
    ?>
	<?php if (have_posts()) : ?>
    <?php while (have_posts()) : the_post(); ?>
    <div class="posts">
    <h2><a href="<?php the_permalink() ?>" title="Click to read <?php the_title(); ?>"><?php the_title(); ?></a></h2>
    <div class="meta">
				By <?php the_author() ?>
			</div>
	<?php theme_excerpt('55'); ?>
    </div>
    
    <?php endwhile; ?>
    	<div class="navigation">
			<div class="alignleft"><?php next_posts_link('&laquo; Older Entries') ?></div>
			<div class="alignright"><?php previous_posts_link('Newer Entries &raquo;') ?></div>
		</div>
            
    <?php else : ?>
    	<p>Sorry, but you are looking for something that isn't here.</p>
    <?php endif; ?>

<?php get_footer(); ?>
