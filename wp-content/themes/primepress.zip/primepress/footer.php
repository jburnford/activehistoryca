	<div id="footer">
		 <a rel="license" href="http://creativecommons.org/licenses/by-nc-sa/2.5/ca/"><img alt="Creative Commons License" style="border-width:0" src="http://i.creativecommons.org/l/by-nc-sa/2.5/ca/88x31.png" /></a><br /><span xmlns:dc="http://purl.org/dc/elements/1.1/" property="dc:title">ActiveHistory.ca</span> by <a xmlns:cc="http://creativecommons.org/ns#" href="http://activehistory.ca/about/" property="cc:attributionName" rel="cc:attributionURL">ActiveHistory.ca Committee and Authors</a> is licensed under a <a rel="license" href="http://creativecommons.org/licenses/by-nc-sa/2.5/ca/">Creative Commons Attribution-Noncommercial-Share Alike 2.5 Canada License</a>. | Logo from <a href="http://vixencreativedesign.com/">Vixen Creative Design</a> | Powered by <strong><a href="http://wordpress.org/">WordPress</a></strong></p>  | A <strong><a href="http://www.techtrot.com/primepress/" title="PrimePress theme homepage">WordPress theme</a></strong> by <strong><a href="http://www.techtrot.com" title="PrimePress author homepage">Ravi Varma</a></strong>
	</div><!--#footer-->

</div><!--#container-->	
	
<div class="clear"></div>	
</div><!--#page-->
<?php wp_footer(); ?>
</body>
</html>