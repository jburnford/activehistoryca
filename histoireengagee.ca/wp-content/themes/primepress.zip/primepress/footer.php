	<div id="footer">
		<p class="left"><?php printf(__('&#169; %1$s <strong>%2$s</strong> | Powered by <strong><a href="http://wordpress.org/">WordPress</a></strong>','primepress'), date('Y'), get_bloginfo('name')); ?></p>
		<p class="right"><?php _e('A <strong><a href="http://www.techtrot.com/primepress/" title="PrimePress theme homepage">WordPress theme</a></strong> by <strong><a href="http://www.techtrot.com" title="PrimePress author homepage">Ravi Varma</a></strong>','primepress'); ?></p>
	</div><!--#footer-->

</div><!--#container-->	
	
<div class="clear"></div>	
</div><!--#page-->
<?php wp_footer(); ?>
</body>
</html>