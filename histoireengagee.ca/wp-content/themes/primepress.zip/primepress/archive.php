<?php get_header(); ?>
	
	<div id="primary" class="looped">
		
		<?php if(have_posts()) : ?>
		
		<?php $post = $posts[0]; // Hack. Set $post so that the_date() works. ?>
		<?php /* If this is a category archive */ if (is_category()) { ?>
		<h1 class="page-title"><?php printf(__('Posts under &#8216;%s&#8217;','primepress'), single_cat_title('',false)); ?></h1>
		<?php /* If this is a tag archive */ } elseif(function_exists('is_tag')&& is_tag()) { ?>
		<h1 class="page-title"><?php printf(__('Posts Tagged &#8216;%s&#8217;','primepress'), single_tag_title('',false)); ?></h1>
		<?php /* If this is a daily archive */ } elseif (is_day()) { ?>
		<h1 class="page-title"><?php printf(__('Posts on &#8216;%s&#8217;','primepress'), get_the_time('F jS, Y')); ?></h1>
		<?php /* If this is a monthly archive */ } elseif (is_month()) { ?>
		<h1 class="page-title"><?php printf(__('Posts from &#8216;%s&#8217;','primepress'), get_the_time('F, Y')); ?></h1>
		<?php /* If this is a yearly archive */ } elseif (is_year()) { ?>
		<h1 class="page-title"><?php printf(__('Posts in &#8216;%s&#8217;','primepress'), get_the_time('Y')); ?></h1>
		<?php /* If this is a paged archive */ } elseif (isset($_GET['paged']) && !empty($_GET['paged'])) { ?>
		<h1 class="page-title"><?php _e('Blog Archives','primepress'); ?></h1>
		<?php } ?>
		
		<?php while(have_posts()) : the_post(); ?>
		
		<div id="post-<?php the_ID(); ?>" <?php if (function_exists('post_class')) { post_class('entry'); } else {echo 'class="entry hentry"';} ?>>
			
			<h2 class="entry-title"><a href="<?php the_permalink(); ?>" rel="bookmark" title="<?php printf(__('Permalink to %s','primepress'), the_title('','',false)); ?>"><?php the_title(); ?></a></h2>
			
			<div class="entry-byline">
				<span class="entry-date"><abbr class="updated" title="<?php the_time('Y-m-d\TH:i:sO'); ?>"><?php the_time('M jS, Y'); ?></abbr></span>
				<address class="author vcard"><?php _e('by ','primepress'); ?><a class="url fn" href="<?php the_author_url(); ?>"><?php the_author(); ?></a>. </address>
				<?php comments_popup_link(__('No comments yet','primepress'), __('1 comment','primepress'), __('% comments','primepress'), 'comments-link', __('Comments are off for this post','primepress')); ?>
				<?php edit_post_link(__('Edit','primepress'), '[', ']'); ?>
			</div>
			
			<div class="entry-content">
				<?php the_excerpt(); ?>
			</div>
		</div><!--.entry-->
		
		<?php endwhile; ?>
		
		<?php include (TEMPLATEPATH . '/navigation.php'); ?>
		
		<?php endif; ?>	

	</div><!--#primary-->
	
<?php get_sidebar(); ?>

<?php get_footer(); ?>