<h2 class="widgettitle search-title"><?php _e('Search','primepress') ?></h2>
<form method="get" id="pp-searchform" action="<?php bloginfo('home'); ?>">
<div>
	<input type="text" name="s" id="s-input" maxlength="150" accesskey="4" title="<?php printf(__('Search %s','primepress'), get_bloginfo('name')); ?>" onblur="this.value=(this.value=='') ? '<?php _e('Type in and hit enter to search','primepress'); ?>' : this.value;" onfocus="this.value=(this.value=='<?php _e('Type in and hit enter to search','primepress'); ?>') ? '' : this.value;" value="<?php _e('Type in and hit enter to search','primepress'); ?>" />
	<input type="hidden" id="s-submit" value="Search" />
</div>
</form>